export const environment = {
  production: true,
  apiUrl: 'http://api-node:3000'
};