import { Component, OnInit } from '@angular/core';
import { ReservaService } from '../../services/reserva.service';
import { BonoService } from '../../services/bono';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.page.html',
  styleUrls: ['./cliente.page.scss'],
  standalone: false,
})
export class ClientePage implements OnInit {

  reservas: any[] = [];
  reservasActivas: number = 0;

  bonoActivo: any = null;
  cargandoBono: boolean = true;

  user: any;

  constructor(
    private reservaService: ReservaService,
    private bonoService: BonoService,
    private auth: AuthService,
    private router: Router
  ) {}

  ngOnInit() {

    this.user = this.auth.getUser();

    this.cargarBono();
    this.cargarReservas();
  }

  // 🔥 BONO
  cargarBono() {

    this.cargandoBono = true;

    this.bonoService
      .getBonoActivo(this.user.id_usuario)
      .subscribe({

        next: (bono) => {
          this.bonoActivo = bono;
          this.cargandoBono = false;
        },

        error: () => {
          this.bonoActivo = null;
          this.cargandoBono = false;
        }

      });
  }

  // 🔥 RESERVAS
  cargarReservas() {

    this.reservaService
      .getReservasCliente(this.user.id_usuario)
      .subscribe({

        next: (data:any[]) => {

          this.reservas = data;

          // ⭐ CALCULO FUERA DEL HTML
          this.reservasActivas = this.reservas
            .filter(r => r.estado === 'activa')
            .length;
        },

        error: err => console.error(err)

      });
  }

  cancelar(reserva:any) {

    this.reservaService
      .cancelarReserva(reserva.id_reserva)
      .subscribe(() => {
        this.cargarReservas();
      });
  }

  irComprarBono() {
    this.router.navigate(['/bonos']);
  }

}
