import { Component, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';
import { UserStateService } from './services/user-state.service';
import { Observable } from 'rxjs';

interface MenuItem {
  title: string;
  url: string;
  icon: string;
}

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: 'app.component.html',
})
export class AppComponent implements OnInit {

  menuItems: MenuItem[] = [];

  // 🔥 observable del bono
  bono$: Observable<any>;

  constructor(
    private auth: AuthService,
    private router: Router,
    private userState: UserStateService
  ) {
    this.bono$ = this.userState.bono$;
  }

  ngOnInit() {

  const user = this.auth.getUser();
  if (!user) return;

  // 🔥 Cargar menú inmediatamente
  this.loadMenu(false);

  // 🔥 Luego reaccionar al bono
  this.userState.bono$.subscribe(bono => {
    this.loadMenu(!!bono);
  });

  if (user.rol === 'cliente') {
    this.userState.loadBono();
  }
}


  loadMenu(tieneBono:boolean) {

  const user = this.auth.getUser();
  if (!user) return;

  if (user.rol === 'cliente') {

    this.menuItems = [
      { title: 'Inicio', url: '/cliente', icon: 'home-outline' },
      { title: 'Mis reservas', url: '/cliente', icon: 'bookmark-outline' },
      { title: 'Mi bono', url: '/mi-bono', icon: 'card-outline' },
    ];

    // 🔥 SOLO si tiene bono
    if (tieneBono) {
      this.menuItems.splice(1, 0, {
        title: 'Horarios',
        url: '/horarios',
        icon: 'calendar-outline'
      });
    }

  }

  if (user.rol === 'profesor') {
    this.menuItems = [
      { title: 'Mis clases', url: '/profesor', icon: 'fitness-outline' },
      { title: 'Horarios', url: '/horarios', icon: 'calendar-outline' },
    ];
  }

  if (user.rol === 'admin') {
    this.menuItems = [
      { title: 'Usuarios', url: '/admin', icon: 'people-outline' },
      { title: 'Clases', url: '/admin', icon: 'barbell-outline' },
      { title: 'Pagos', url: '/admin', icon: 'card-outline' },
    ];
  }
}

  

  logout() {
    this.userState.clear();
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
